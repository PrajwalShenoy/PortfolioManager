package controllertest.guitest;

import org.junit.Test;

import controller.gui.JSetCommissionController;
import model.User;
import view.gui.JView;
import view.gui.JViewImpl;

import static org.junit.Assert.assertEquals;

/**
 * Tests to verify the functionality of SetCommission GUI which basically lets user set a
 * different commission.
 */
public class SetCommissionForUserControllerTest extends TestHelperGUIController {

  private JView mockView = new JViewImpl();

  @Test
  public void testMain() {
    try {
      User createdUser = this.createUserWith1FlexiblePortfoliosAndStocks();
      JSetCommissionController jSetCommissionController = new JSetCommissionController(model);
      jSetCommissionController.setView(mockView);
      jSetCommissionController.setUser(createdUser);
      jSetCommissionController.setCommission("5");
      assertEquals(createdUser.getCommission(), 5.0, 0);
    } catch (Exception e) {
      throw new RuntimeException();
    }
  }
}
